
# Required packages -------------------------------------------------------

library(dplyr)
library(readr)
library(stringr)
library(purrr)

library(igraph)

library(ggplot2)
library(ggpubr)
library(scales)

library(kableExtra)


# Required data -----------------------------------------------------------

# Paths to important files

# Command arguments -------------------------------------------------------

cargs <- commandArgs(trailingOnly = TRUE)
target_format <- cargs[1]
gene <- cargs[2]


# Sourcing local functions ------------------------------------------------

# Local functions need throughout the bookdown
source("code/utility_fn.R")
source("code/conn_probabilities.R")

# Load necessary data -----------------------------------------------------

# Read in tables shared by all sections in the book

# Rendering the book ------------------------------------------------------

fmt <- "bookdown::gitbook"
bookdown::render_book(input = "index.Rmd", 
                      output_format = fmt,
                      clean = FALSE,
                      output_dir = "KG_results",
                      output_yaml = "_gitbook_out.yml")


