library(dplyr)

## getting all the gene-disease connections with 2 hops regardless of the tissue
thop<-read.table("/path/to/Kg_predictions_100821/notissue/2hop_notissue.csv", sep=",", header = T)

#hops<-rbind(ohop[,c("from", "to")], thop[,c("from", "to")])
hops<-unique(thop[,c("from", "to")])
hops["lbl"]<-1

# data for training (gene-gene and gene-disease edges before2010)
data<-read.table("data/KG/data_labeled.csv", sep=";", header = T)
# test for validation (gene-disease edges after2010)
test<-read.table("data/KG/test_labeled.csv", sep=";", header = T)

colnames(data)<-c("from","to", "lbl")
colnames(test)<-c("from","to", "lbl")

write.table(data, "data/KG/data_links.csv", sep = "\t", col.names = T, row.names = F, quote = F )

## filtering out the links that already exist in the test and train data
diff1<- setdiff(hops, test)
diff2<- setdiff(diff1, data)

## assigning negative to true negatives
diff2["lbl"]<-0

## assigning negative values to the train data as its size
data1<-rbind(data, head(diff2, 95287))
data1["train"]<-"train"

## assigning negative values to the test data as its size
test1<-rbind(test, tail(diff2, 5176))
test1["train"]<-"test"

#merge them
all_data<-rbind(data1, test1)
rownames(all_data) <- 1:nrow(all_data)

#write.table(all_data[,c("from","to","lbl")], "data/Training/all_data.csv",sep=";", row.names = T, col.names = T, quote = F)
all_data<-unique(all_data)
rownames(all_data) <- 1:nrow(all_data)
#shuffle the rows
set.seed(42)
rows <- sample(nrow(all_data))
all_data_shuffles<-all_data[rows,]

#all_data_shuffles<-unique(all_data_shuffles)


#seperate them now because i will need their row numbers (indexes)
data_labeled<-unique(all_data_shuffles[all_data_shuffles$train %in% "train",])
test_labeled<-unique(all_data_shuffles[all_data_shuffles$train %in% "test",])
## i use this files to get the row numbers of train and test
write.table(data_labeled[,c("from","to","lbl")], "data/Training/data_labeled_0-1.csv",sep=";", row.names = T, col.names = T, quote = F)
write.table(test_labeled[,c("from","to","lbl")], "data/Training/test_labeled_0-1.csv",sep=";", row.names = T, col.names = T, quote = F)

## all labeled data
write.table(all_data_shuffles[,c("from","to","lbl")], "data/Training/all_labeled_0-1.csv",sep=";", row.names = T, col.names = T, quote = F)






