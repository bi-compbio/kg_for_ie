# helper functions

# fraction of edges that connects pairwise node groups
get_percentage_edges <- function(g, group, tol = 1e-8) {
  list.group <- split(V(g)$name, group)
  
  tab.edges <- sapply(list.group, function(grp.row) {
    sapply(list.group, function(grp.col) {
      length(E(g)[from(grp.row) & to(grp.col)])
    })
  })
  
  tab.ans <- t(tab.edges)/ecount(g)
  
  # check that they sum up to 1
  stopifnot(abs(sum(tab.ans) - 1) < tol)
  tab.ans
}

### Some functions borrowed from
# https://github.com/b2slab/diffuBench/blob/master/helper_funs.R

# descriptive stats
describe_net <- function(g) {
  # g <- barabasi.game(1000, power = 1, m = 3)
  # g
  deg <- igraph::degree(g, mode = "all")
  plf <- igraph::fit_power_law(x = deg + 1, xmin = 5)
  data.frame(
    Nodes = igraph::vcount(g), 
    Edges = igraph::ecount(g), 
    EdgeDensity = igraph::graph.density(g), 
    PowerLawCoefficient = plf$alpha
  )
}

# K: kernel sub-matrix (not necessarily square)
# mu_y: mean of input vector y
get_mu <- function(K, mu_y) {
  mu_y*rowSums(K)
}

# K: kernel sub-matrix (not necessarily square)
# var_y: variance of input vector y
# 
# changed denom to n-1 because it's simpler
get_covar <- function(K, var_y) {
  # n <- ncol(K)
  Kn <- K - rowMeans(K)
  
  # (var_y*n/(n - 1))*tcrossprod(Kn)
  var_y*tcrossprod(Kn)
}

# K: kernel sub-matrix (not necessarily square)
get_ebias <- function(K) {
  get_mu(K, mu_y = 1)
}

# K: kernel sub-matrix (not necessarily square)
# this one is slow but illustrative
get_vbias_ <- function(K) {
  log10(diag(get_covar(K, var_y = 1)))
}
# faster
get_vbias <- function(K) {
  n <- ncol(K)
  # apply(K, 1, var) = KK^T/(nl - 1)
  # bias = log10(nl/(nl - 1)*KK^T)
  log10(apply(K, 1, var)*(n - 1))
}
# equivalent formulation
get_vbias2 <- function(K) {
  n <- ncol(K)
  # bias(i) = sum_j ((k_ij - mean(k_i*))**2)
  log10(rowSums((K - get_ebias(K)/n)**2))
}

### End borrow