
library(readr)
library(dplyr)
library(ggplot2)
library(scales)

config <- new.env()
source("config.R", config)

dfolder <- ""

# Gene-gene interactions --------------------------------------------------

ppi_bef <- read_csv(paste0(dfolder, config$gs.root, 
                           "ensgene-interactions-before2010_040821.csv"),
                    col_names = c("id", "link_id", "entrez gene2", "entrez gene1", 
                                  "protein2", "protein1",   "name1", "name2", 
                                  "Interaction", "trust", "class1", "class2", 
                                  "gene1", "gene2", "weight", "pmid", 
                                  "first_year", "last_year"), skip = 1) %>% 
  filter(!is.na(link_id))

ppi_aft <- read_csv(paste0(dfolder,config$gs.root, 
                           "protein-interactions-after2010_220621.tsv"),
                    col_names = c("id", "link_id","gene2","gene1","protein2",
                                  "protein1","name1","name2","Interaction",
                                  "trust","class1","class2","ensembl1",
                                  "ensembl2","weight","pmid",
                                  "first_year","last_year"), skip = 1) %>% 
  filter(!is.na(link_id))


# Make sure that the max. first_year in Before2010 is 2010 and that 
# the min. first_year in After2010 is 2011
max(ppi_bef$first_year)
min(ppi_aft$first_year)



# Gene-disease links ------------------------------------------------------

dgi_bef <-  read_csv(paste0(dfolder, config$gs.root, 
                            "ensgene-disease-links-before2010_040821.csv"),
                     col_names = c("id","gene","Mesh","disease_name","pumbed_count",
                                   "pubmeds","years","first_ref","last_ref","entrez gene"), skip = 1) %>% 
  filter(!is.na(gene))

dgi_aft <-  read_csv(paste0(dfolder, config$gs.root, 
                            "ensgene-disease-links-after2010_040821.csv"),
                     col_names = c("gene","Mesh","disease_name","pumbed_count",
                                   "pubmeds","years","first_ref","last_ref","entrez gene"), skip = 1) %>% 
  filter(!is.na(gene))

max(dgi_bef$first_ref)
min(dgi_aft$first_ref)

# Gold standard -----------------------------------------------------------

# The gold standard is generated from the After2010 gene-disease network by
# making sure that only genes and disease from the Before2010 network are 
# included since these are the only cases that can be predicted

# Genes
genes_bef <- unique(dgi_bef$gene)
genes_bef <- genes_bef[!is.na(genes_bef)]

# Diseases
disease_bef <- unique(dgi_bef$Mesh)
disease_bef <- disease_bef[!is.na(disease_bef)]

gold_std <- dgi_aft %>% 
  filter(gene %in% genes_bef) %>% 
  filter(Mesh %in% disease_bef) %>% 
  rename(from = gene, to = Mesh)

hop_info <- read_tsv(config$direct_hops,
                     col_names = c("id","from", "to", "weight", "hop_type",	"entrez_gene"),
                     skip = 1)

gs_hop <- left_join(gold_std, hop_info, by = c("from", "to")) %>% 
  mutate(hop_type = ifelse(is.na(hop_type), ">2hops", hop_type))

ggplot(gs_hop, aes(hop_type)) +
  geom_bar() +
  scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  annotation_logticks(sides = "l") +
  labs(x = "Gene-disease link separation in KG", y = "Count") +
  theme_bw()

# To provide fairer performance metrics, we further filter down the gold standard 
# by removing gene-disease separated by more than 2 hops in the original KG.

gs_final <- gs_hop %>% 
  filter(hop_type != ">2hops") %>% 
  select(from, to) %>% 
  filter(!duplicated(.)) %>% 
  mutate(lbl = 1)

write_csv(gs_final, "data/links/gold_std_110821.csv")
