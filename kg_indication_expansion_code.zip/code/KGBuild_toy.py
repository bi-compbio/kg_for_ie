from rdflib.graph import Graph
from rdflib import URIRef, RDFS, Literal, RDF, OWL
import csv
import pandas as pd
import rdflib
from rdflib.namespace import XSD

nodesfile="data/KG/nodes_toy.csv"
edgesfile="data/KG/edges_toy.csv"

def build_KG(edgesfile,nodesfile):
        
        namespace = "http://data.com/"
        g = Graph()

        with open(nodesfile, newline='') as csvfile:
                data = pd.DataFrame(csv.reader(csvfile))

                data.columns=["node_id","node_type","node_name"]
                data=data.iloc[1:]


                for row in data.itertuples():
                        node = URIRef(namespace + row[1].replace(" ","_").replace("|","_"))
                        type= URIRef(namespace + row[2].replace(" ","_"))
                        g.add((node, RDF.type, type))
                        label= Literal(row[3])
                        g.add((node, RDFS.label, label))

                
  
        with open(edgesfile, newline='') as csvfile2:
                edgedata = pd.DataFrame(csv.reader(csvfile2))
        
                edgedata.columns=["from","to","edgeType","weight","edgeName", "pubmed"] #1-6
                edgedata=edgedata.iloc[1:]
                publication = URIRef(namespace + 'Publication')
                g.add((publication, RDF.type, OWL.Class))
                expression = URIRef(namespace + 'Expression')
                g.add((expression, RDF.type, OWL.Class))
                linksIn=URIRef(namespace + "linksIn")
                linksOut=URIRef(namespace + "linksOut")
                g.add((linksIn, RDF.type, OWL.ObjectProperty))
                g.add((linksOut, RDF.type, OWL.ObjectProperty))
                pubmedCount=URIRef(namespace + "PubmedCount")
                g.add((pubmedCount, RDF.type, OWL.DataProperty))
                weight=URIRef(namespace + "Weight")
                g.add((weight, RDF.type, OWL.DataProperty))
                pubmed=URIRef(namespace + "Pubmed")
                g.add((pubmed, RDF.type, OWL.DataProperty))
        
                for row2 in edgedata.itertuples():
                        node1=URIRef(namespace + row2[1].replace(" ","_").replace("|","_"))
                        node2=URIRef(namespace + row2[2].replace(" ","_").replace("|","_"))
                        relation=URIRef(namespace + row2[5].replace(" ","_").replace(",",""))
                        g.add((relation, RDF.type, OWL.ObjectProperty))
                        g.add((node1,relation,node2))
                        g.add((relation,RDFS.label,Literal(row2[5])))
                        if(row2[3] == "Interaction" or row2[3] == "hasDisease" ):
                                node3=URIRef(namespace + row2[1].replace(" ","_").replace("|","_")+"_"+row2[2].replace(" ","_").replace("|","_"))
                                g.add((node3,RDF.type, publication))
                                g.add((node1, linksIn, node3))
                                g.add((node3, linksOut, node2))
                                if(row2[4] == "NA"):
                                        g.add((node3, pubmedCount, Literal(0)))
                                else:
                                        g.add((node3, pubmedCount, Literal(row2[4], datatype=XSD.integer)))
                                g.add((node3, pubmed, Literal(row2[6])))
                        elif(row2[3] == "hasProteinExpression" or row2[3] == "hasRNAExpression"):
                                node4=URIRef(namespace + row2[1].replace(" ","_").replace("|","_")+"_"+row2[2].replace(" ","_").replace("|","_"))
                                g.add((node4,RDF.type, expression))
                                g.add((node1, linksIn, node4))
                                g.add((node4, linksOut, node2))
                                g.add((node4, weight, Literal(row2[4])))
        print("2")

        f = open("sample.rdf", "wb")
        f.write(g.serialize(format='turtle'))
        f.close()
        
        
