
get_entrez_link <- function(entrez_id, link_text=entrez_id){
  base_url <- "https://www.ncbi.nlm.nih.gov/gene/?term="
  paste0("[", link_text, "](", base_url, entrez_id, "){target='_blank'}")
}

get_ensembl_link <- function(ensembl_id, link_text=ensembl_id){
  base_url <- "https://www.ensembl.org/id/"
  paste0("[",  link_text, "](", base_url, ensembl_id, "){target='_blank'}")
}

get_uniprot_link <- function(uniprot_id, link_text=uniprot_id){
  base_url <- "https://www.uniprot.org/uniprot/"
  paste0("[",  link_text, "](", base_url, uniprot_id, "){target='_blank'}")
}

get_hugo_link <- function(hugo_id, link_text=hugo_id){
  base_url <- "https://www.genenames.org/data/gene-symbol-report/#!/hgnc_id/HGNC:"
  paste0("[",  link_text, "](", base_url, hugo_id, "){target='_blank'}")
}

get_pharmgkb_link <- function(pharmgkb_id, link_text=pharmgkb_id){
  base_url <- "https://www.pharmgkb.org/gene/"
  paste0("[",  link_text, "](", base_url, pharmgkb_id, "){target='_blank'}")
}

get_pharos_link <- function(uniprot_id, link_text=uniprot_id){
  base_url <- "https://pharos.nih.gov/targets/"
  paste0("[", link_text, "](", base_url, uniprot_id, "){target='_blank'}")
}

get_go_link <- function(go_id, link_text=go_id){
  base_url <- "https://www.ebi.ac.uk/QuickGO/term/"
  paste0("[", link_text, "](", base_url, go_id, "){target='_blank'}")
}

get_reactome_link <- function(reactome_id, link_text=reactome_id){
  base_url <- "https://reactome.org/content/detail/"
  paste0("[", link_text, "](", base_url, reactome_id, "){target='_blank'}")
}

get_kegg_link <- function(kegg_id, link_text=kegg_id){
  base_url <- "https://www.genome.jp/pathway/"
  paste0("[", link_text, "](", base_url, kegg_id, "){target='_blank'}")
}

get_smpdb_link <- function(smpdb_id, link_text=smpdb_id){
  base_url <- "https://smpdb.ca/view/"
  # Extract the numeric part of the id and then add 0s to the left to complete
  # 7 characters
  num_part <- as.character(readr::parse_number(smpdb_id))
  smpdb_id <- str_pad(num_part, width = 7, side = "left", pad = "0")
  smpdb_id <- paste0("SMP", smpdb_id)
  paste0("[", link_text, "](", base_url, smpdb_id, "){target='_blank'}")
}

get_pubmed_link <- function(pubmed_id, link_text=pubmed_id){
  base_url <- "https://pubmed.ncbi.nlm.nih.gov/"
  paste0("[", link_text, "](", base_url, pubmed_id, "){target='_blank'}")
}

get_hpa_link <- function(ensembl_id, gene_symbol, link_text=ensembl_id){
  base_url <- "https://www.proteinatlas.org/"
  paste0("[", link_text, "](", base_url, ensembl_id, "-", gene_symbol, "){target='_blank'}")
}

get_otg_gene_link <- function(ensembl_id, link_text=ensembl_id){
  base_url <- "https://genetics.opentargets.org/gene/"
  paste0("[", link_text, "](", base_url, ensembl_id, "){target='_blank'}")
}

get_otg_study_link <- function(study_id, link_text=study_id){
  base_url <- "https://genetics.opentargets.org/study/"
  paste0("[", link_text, "](", base_url, study_id, "){target='_blank'}")
}

get_otg_variant_link <- function(variant_id, link_text=variant_id){
  base_url <- "https://genetics.opentargets.org/variant/"
  paste0("[", link_text, "](", base_url, variant_id, "){target='_blank'}")
}

get_mgi_allele_link <- function(allele_id, link_text=allele_id){
  base_url <- "http://www.informatics.jax.org/allele/"
  paste0("[", link_text, "](", base_url, allele_id, "){target='_blank'}")
}

get_gnomad_link <- function(ensembl_id, link_text=ensembl_id){
  base_url <- "https://gnomad.broadinstitute.org/gene/"
  paste0("[", link_text, "](", base_url, ensembl_id, "){target='_blank'}")
}

render_table <- function(tb, fsize = NULL){
  if(is.null(tb)){
    print("There is no data for this target", quote = FALSE)
  }else{
    if(fmt == "bookdown::gitbook"){
      tb %>%
        kable(format = "html") %>%
        kable_styling(bootstrap_options = "striped", font_size = fsize)
    }else if(fmt == "bookdown::word_document2"){
      tb %>%
        kable(format = "pipe")
    }
  }
}

get_tb_from_list <- function(list_var){
  if(class(list_var[[1]]) == "list"){
    bind_rows(lapply(list_var, as_tibble))
  }else{
    as_tibble(list_var)
  }
}
