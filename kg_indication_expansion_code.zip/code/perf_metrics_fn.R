# Remove duplicates (keeps entries with highest weight)
clean_preds <- function(tb){
  tb <- tb %>% 
    select(from, to, weight) %>% 
    group_by(from, to) %>% 
    summarise(weight = max(weight)) %>% 
    ungroup() %>% 
    arrange(desc(weight))
  return(tb)
}

# Read predictions 
read_no_dups <- function(path){
  tb <- read_csv(path) %>% 
    clean_preds()
  return(tb)
}

# Compute precision and recall based on the gold standard reference
get_performance <- function(tb, ref, at = NA, metric = "prec"){
  tb <- left_join(tb, ref, by = c("from", "to")) %>% 
    mutate(lbl = ifelse(is.na(lbl), 0, lbl))
  positives <- nrow(ref)
  if(!is.na(at)){
    tb <- tb[1:at,]
  }
  if(metric == "prec"){
    return(sum(tb$lbl)/nrow(tb))
  }else if(metric == "reca"){
    return(sum(tb$lbl)/positives)
  }else if(metric == "f1"){
    pr <- sum(tb$lbl)/nrow(tb)
    re <- sum(tb$lbl)/positives
    return(2*((pr*re)/(pr+re)))
  }
}

get_performance2 <- function(tb, at = NA, metric = "prec"){
  
  #tb3<-tb
  tb<-tb[tb$Expected_Output %in% 1,]
  ref<-tb
  
  tb<-tb %>%
    mutate(match = if_else(Predicted_output == Expected_Output, 1, 0))
  
  
  if(!is.na(at)){
    tb <- tb[1:at,]
  }
  if(metric == "prec"){
    return(sum(tb$match)/nrow(tb))
  }else if(metric == "reca"){
    return(sum(tb$match)/nrow(ref))
  }else if(metric == "f1"){
    pr <- sum(sum(tb$match)/nrow(tb))
    re <- sum(tb$match)/nrow(ref)
    return(2*((pr*re)/(pr+re)))
  }
}