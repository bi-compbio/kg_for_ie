#' Check whether short distances in latent space are indicative of gene-disease links
#'
#' Given a gene-disease network and the latent coordinates of its nodes, compute
#' the fraction of existing edges between all genes and diseases whose pairwise
#' distances are within the considered bin.
#' 
#' @param net data frame; A gene-disease network.
#' @param coords data frame; Low-dimensional coordinates of all nodes in the network. 
#'        Two columns are mandatory, node_id and coord. The latter is a comma-separated
#'        list of numbers
#' @param pattern character; A pattern to recognize between genes and diseases (default = "^D").
#' @param bins numeric; The number of distance bins to consider (default = 10).
#' 
#' @return A data frame with the two following elements:
#' \item{dist}{The considered distance bins.}
#' \item{prob}{the connection probabilities within each bin.}
#' 
#' @author Gregorio Alanis-Lobato
#' 
#' @references Papadopoulos, F. et al. (2012) Popularity versus similarity in growing networks. \emph{Nature} 489(7417):537-40.
#' 
#' @examples 
#' # Generate an artificial network
#' net <- expand.grid(from = paste0("Gene_", sample(LETTERS, 20)), 
#'                    to = paste0("Disease_", sample(LETTERS, 5)), 
#'                    stringsAsFactors = FALSE)
#' net$link <- sample(c(1, 0), nrow(net), replace = TRUE)
#' net <- net[net$link == 1, ]
#' 
#' # Assign random coordinates to the nodes in 2-dimensional space
#' coords <- data.frame(node_id = union(net$from, net$to), 
#'                      stringsAsFactors = FALSE)
#' coords$coord <- sapply(1:nrow(coords), 
#'                        function(x) paste(runif(2), collapse = ","))
#'
#' # Get the connection probability curve and plot it
#' conn <- get_conn_probs(net, coords, 3)
#' 
#' plot(conn$dist, conn$prob, pch = 16, xlab = "Distance in latent space", ylab = "Connection probability")
#' 
#' @export
#' @import igraph
#' 
#'
library(stringr)

get_conn_probs <- function(net, coords, pattern = "^D", bins = 10){
  
  # Separate gene from disease coords
  gene_coords <- coords[!grepl(pattern, coords$node_id), ]
  gcoords <- sapply(gene_coords$coord, function(x) strsplit(x, split = ","))
  gcoords <- t(sapply(gcoords, function(x) as.numeric(x)))
  rownames(gcoords) <- gene_coords$node_id
  
  disease_coords <- coords[grepl(pattern, coords$node_id), ]
  dcoords <- sapply(disease_coords$coord, function(x) strsplit(x, split = ","))
  dcoords <- t(sapply(dcoords, function(x) as.numeric(x)))
  rownames(dcoords) <- disease_coords$node_id
  
  # Compute the matrix of pairwise distances between nodes
  # WARNING: This can be quite computationally intensive!!!
  D <- sapply(seq(nrow(gcoords)), function(i) rowSums(sweep(dcoords, 
                                                            MARGIN = 2, 
                                                            FUN = "-", 
                                                            gcoords[i,])^2))
  colnames(D) <- rownames(gcoords)
  D <- t(D)
  
  # The network's adjacency matrix serves as the reference for edge existence
  g <- graph_from_data_frame(net, directed = TRUE)
  ref <- as_adjacency_matrix(g, sparse = F)
  #ref <- ref[rownames(D), colnames(D)]
  
  # Get rid of useless data
  rm(net, coords)
  
  max.dist <- max(D)
  
  steps <- seq(0, max.dist, length.out = bins)
  
  res <- data.frame(dist = steps, prob = vector("numeric", length = bins), stringsAsFactors = F)
  
  for(i in 1:(bins - 1)){
    res$prob[i] <- sum(ref[(D >= steps[i]) & (D < steps[i + 1])])/sum((D >= steps[i]) & (D < steps[i + 1]))
  }
  
  # Compute the last probability
  res$prob[bins] <- sum(ref[D >= steps[bins]])/sum(D >= steps[bins])
  
  # Change all NAs to 0. These are cases where there are no distances in the given window
  res$prob[is.na(res$prob)] <- 0
  
  return(res)
}

