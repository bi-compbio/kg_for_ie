
library(dplyr)
library(readr)
library(igraph)
library(ggplot2)

source("code/conn_probabilities.R")

net <- read_tsv("data/KG/data_links.csv")
coords <- read_tsv("data/KG/2D_PCA_metabase_before2010_skipgram_3_500_200.tsv")
coords2 <- read_tsv("data/KG/2D_PCA_gene-disease_DistMult.tsv")
coords3 <- read_tsv("data/KG/2D_PCA_gene-disease_TransH.tsv")
coords4 <- read_tsv("data/KG/2D_PCA_gene-disease_TransE.tsv")
coords5 <- read_tsv("data/KG/2D_PCA_gene-disease_TransD.tsv")

res1 <- get_conn_probs(net, coords, pattern = "^D", bins = 10)
res1["method"]<-"rdf2vec"

res2 <- get_conn_probs(net, coords2, pattern = "^D", bins = 10)
res2["method"]<-"distmult"

res3 <- get_conn_probs(net, coords3, pattern = "^D", bins = 10)
res3["method"]<-"transH"

res4 <- get_conn_probs(net, coords4, pattern = "^D", bins = 10)
res4["method"]<-"transE"

res5 <- get_conn_probs(net, coords5, pattern = "^D", bins = 10)
res5["method"]<-"rdf2vec-randomwalk"

res<-rbind(res1, res2, res3, res4, res5)

# color=method
ggplot(res, aes(dist, prob, color=method)) +
  geom_point() +
  geom_line() +
  labs(x = "Low-dimensional distance", y = "Connection probability") +
  theme_bw()
